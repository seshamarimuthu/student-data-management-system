<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
    <div class="box">
        <h1>Edit Student</h1>
        <form action="<?php echo e(route('student.update', $student->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input">
                <input type="text" name="name" placeholder="Name" value="<?php echo e($student->name); ?>" required>
            </div>
            <div class="input">
                <input type="email" name="email" placeholder="Email" value="<?php echo e($student->email); ?>" readonly required>
            </div>
            <div class="input">
                <input type="number" name="phone" placeholder="Phone" value="<?php echo e($student->phone); ?>" >
            </div>
            <div class="input">
                <input type="text" name="address" placeholder="Address" value="<?php echo e($student->address); ?>">
            </div>
            <div class="input">
                <select name="gender">
                    <option value="">Gender</option>
                    <option value="Male" <?php echo e($student->gender == 'Male' ? 'selected' : ''); ?>>Male</option>
                    <option value="Female" <?php echo e($student->gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                    <option value="Other" <?php echo e($student->gender == 'Other' ? 'selected' : ''); ?>>Other</option>
                </select>
            </div>
            <div class="input">
                <input type="text" name="department" placeholder="Department" value="<?php echo e($student->department); ?>">
            </div>
            <div class="input">
                <input hidden type="text" name="usertype" placeholder="User Type" value="<?php echo e($student->usertype); ?>">
            </div>
            <div class="input">
                <input type="checkbox" id="parttime" name="parttime" value="1" <?php echo e($student->parttime ? 'checked' : ''); ?>>
                <label for="parttime">Part-time</label>
            </div>
            <div class="input">
                <input type="date" name="joining_date" value="<?php echo e($student->joining_date); ?>">
            </div>
            <div class="btn">
                <button type="submit" class="signup-btn">Update</button>
            </div>
        </form>
    </div>
</body>
</html>
<?php /**PATH D:\Laravel\student-data-management-system\resources\views/edit.blade.php ENDPATH**/ ?>