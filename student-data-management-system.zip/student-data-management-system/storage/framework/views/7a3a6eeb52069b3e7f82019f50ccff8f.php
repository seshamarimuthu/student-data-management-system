<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>"></head>
<body>
    <div class="box">
        <h1>Registration Form</h1>
        <form action="/add-data" method="POST">
            <?php if($errors->any()): ?>
            <div class="input" style="color: red;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <div class="input">
                <input type="text" id="name" name="name" placeholder="name" value="" required>
            </div>

            <div class="input">
                <input type="email" id="email" name="email" placeholder="email" value="" required>
            </div>

            <div class="input">
                <input type="number" id="phone" name="phone" placeholder="phone" >
            </div>
            <div class="input">
                <input type="address" id="address" name="address" placeholder="address" required>
            </div>
            <div class="input">
                <select class="input" name="gender" required>
                    <option value="">gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="input">
                <input type="text" class="form-control" name="department" placeholder="department" required>
            </div>
            <?php if(empty($usertype)): ?>
            <div class="input">
                <input type="text" name="usertype" placeholder="usertype">
            </div>
            <?php endif; ?>
            <div class="input">
                <input type="checkbox" id="parttime" name="parttime" value="1" >
                <label for="parttime">parttime</label>
            </div>
            <div class="input">
                <input type="date" class="form-control" name="joining_date"  required>
            </div>

            <?php echo csrf_field(); ?>
            <div class="btn">
                <button style="cursor: pointer;" type="submit" class="signup-btn">Register</button>
            </div>
            <p style="color: #1877f2;">Already have an account? <a href="/login">Log In</a></p>
        </form>
    </div>
</body>
</html>
<?php /**PATH D:\Laravel\student-data-management-system\resources\views/register.blade.php ENDPATH**/ ?>