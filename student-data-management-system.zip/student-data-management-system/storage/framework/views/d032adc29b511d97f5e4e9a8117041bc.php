<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Student List</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

    <body>
    <div class="container">
        <h1>Student List</h1>
        <?php if(session('email')): ?>
        
    <?php endif; ?>
        <?php if($students): ?>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Gender</th>
                        <th>Department</th>
                        <th>Parttime</th>
                        <th>Joining date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($student->name); ?></td>
                            <td><?php echo e($student->email); ?></td>
                            <td><?php echo e($student->phone); ?></td>
                            <td><?php echo e($student->address); ?></td>
                            <td><?php echo e($student->gender); ?></td>
                            <td><?php echo e($student->department); ?></td>
                            <td><?php echo e($student->parttime == 1 ? 'Yes' : 'No'); ?></td>
                            <td><?php echo e($student->joining_date); ?></td>
                            <td>
                                <a href="/students/edit/<?php echo e($student->id); ?>">Edit</a>
                                <form action="/students/delete/<?php echo e($student->id); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <a style="float: right;color:red" href="/students/logout">Logout</a>
            </table>
        <?php else: ?>
            <p>You do not have permission to view this data.</p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH D:\Laravel\student-data-management-system\resources\views/data.blade.php ENDPATH**/ ?>