<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>

    <div class="box">
        <h1>Login Form</h1>
        <?php if(session('message')): ?>
        <div style="color: red" class="alert">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
        <form action="/login-data" method="POST">

            <div class="input">
                <input type="text" id="name" name="name" placeholder="name" value="" required>
            </div>

            <div class="input">
                <input type="email" id="email" name="email" placeholder="email" value="" required>
            </div>


            <?php echo csrf_field(); ?>
            <div class="btn">
                <button style="cursor: pointer;" type="submit" class="signup-btn">Log In</button>
            </div>
            <p style="color: #1877f2;">Don't have an account yet? <a href="/">Sign Up</a></p>
        </form>
    </div>
</body>
</html>
<?php /**PATH D:\Laravel\student-data-management-system\resources\views\login.blade.php ENDPATH**/ ?>