<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class StudentController extends Controller
{
    public function registerform(){
        $students = Student::all();
        $usertype = !empty($students[0]->usertype)?$students[0]->usertype:'';
        return view('register',compact('usertype'));
    }

    public function adddata(Request $request) {
        $request->validate([
            'email' => 'required|email|unique:students,email',
        ]);

        Student::create($request->all());

        return view('login')->with('message', 'Registration successful! You can now log in.');
    }

    public function login(){
        return view('login');
    }

    public function logindata(Request $request) {

        if ($request->isMethod('get')) {
            return view('login');
        }
        $request->validate([
            'name' => 'required|string',
            'email' => 'required|email',
        ]);

        $student = Student::where('email', $request->email)
                          ->where('name', $request->name)
                          ->where('usertype', 'admin')
                          ->first();

        if ($student) {
            Session::put('email', $student->email);
            return view('data', ['students' => Student::all()]);
        } else {
            $student = Student::where('email', $request->email)
                                ->where('name', $request->name)
                                ->first();

            if ($student) {
                Session::put('email', $student->email);
                return view('data', ['students' => [$student]]);
            } else {
                return redirect()->back()->with('message', 'No data found. Please check your credentials.');
            }
        }
    }

    public function logout() {
        Session::flush();
        return redirect()->route('login');
    }

    public function edit($id) {
        $student = Student::findOrFail($id);
        return view('edit', compact('student'));
    }

    public function update(Request $request, $id) {
        $student = Student::findOrFail($id);
        $student->update($request->all());

        return redirect()->route('login')->with('message', 'Updated successful! You can now log in.');
    }

    public function destroy($id) {
        $student = Student::findOrFail($id);
        $student->delete();

        return redirect()->route('login')->with('message', 'Student deleted successfully.');
    }


}
