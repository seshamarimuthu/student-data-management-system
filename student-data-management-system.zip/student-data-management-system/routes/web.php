<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;

Route::get('/', [StudentController::class,'registerform']);
Route::post('/add-data', [StudentController::class,'adddata']);
Route::get('/login', [StudentController::class,'login'])->name('login');

Route::post('/login-data', [StudentController::class,'logindata']);
Route::get('/login-data', [StudentController::class,'login']);

Route::get('/students/edit/{id}', [StudentController::class, 'edit'])->name('student.edit');
Route::post('/students/update/{id}', [StudentController::class, 'update'])->name('student.update');

Route::post('/students/delete/{id}', [StudentController::class, 'destroy'])->name('student.delete');
Route::get('/students/logout', [StudentController::class, 'logout']);

