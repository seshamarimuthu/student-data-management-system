<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Student List</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">

    <body>
    <div class="container">
        <h1>Student List</h1>
        @if(session('email'))
        {{-- <p>Logged in as: {{ session('token') }}</p> --}}
    @endif
        @if($students)
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Gender</th>
                        <th>Department</th>
                        <th>Parttime</th>
                        <th>Joining date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($students as $student)
                        <tr>
                            <td>{{ $student->name }}</td>
                            <td>{{ $student->email }}</td>
                            <td>{{ $student->phone }}</td>
                            <td>{{ $student->address }}</td>
                            <td>{{ $student->gender }}</td>
                            <td>{{ $student->department }}</td>
                            <td>{{ $student->parttime == 1 ? 'Yes' : 'No' }}</td>
                            <td>{{ $student->joining_date }}</td>
                            <td>
                                <a href="/students/edit/{{ $student->id }}">Edit</a>
                                <form action="/students/delete/{{ $student->id }}" method="POST" style="display:inline;">
                                    @csrf
                                    <button type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
                <a style="float: right;color:red" href="/students/logout">Logout</a>
            </table>
        @else
            <p>You do not have permission to view this data.</p>
        @endif
    </div>
</body>
</html>
