<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}"></head>
<body>
    <div class="box">
        <h1>Registration Form</h1>
        <form action="/add-data" method="POST">
            @if ($errors->any())
            <div class="input" style="color: red;">
                @foreach ($errors->all() as $error)
                    <p>{{ $error }}</p>
                @endforeach
            </div>
            @endif
            <div class="input">
                <input type="text" id="name" name="name" placeholder="name" value="" required>
            </div>

            <div class="input">
                <input type="email" id="email" name="email" placeholder="email" value="" required>
            </div>

            <div class="input">
                <input type="number" id="phone" name="phone" placeholder="phone" >
            </div>
            <div class="input">
                <input type="address" id="address" name="address" placeholder="address" required>
            </div>
            <div class="input">
                <select class="input" name="gender" required>
                    <option value="">gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="input">
                <input type="text" class="form-control" name="department" placeholder="department" required>
            </div>
            @if (empty($usertype))
            <div class="input">
                <input type="text" name="usertype" placeholder="usertype">
            </div>
            @endif
            <div class="input">
                <input type="checkbox" id="parttime" name="parttime" value="1" >
                <label for="parttime">parttime</label>
            </div>
            <div class="input">
                <input type="date" class="form-control" name="joining_date"  required>
            </div>

            @csrf
            <div class="btn">
                <button style="cursor: pointer;" type="submit" class="signup-btn">Register</button>
            </div>
            <p style="color: #1877f2;">Already have an account? <a href="/login">Log In</a></p>
        </form>
    </div>
</body>
</html>
