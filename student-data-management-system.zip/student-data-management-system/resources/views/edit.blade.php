<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
</head>
<body>
    <div class="box">
        <h1>Edit Student</h1>
        <form action="{{ route('student.update', $student->id) }}" method="POST">
            @csrf
            <div class="input">
                <input type="text" name="name" placeholder="Name" value="{{ $student->name }}" required>
            </div>
            <div class="input">
                <input type="email" name="email" placeholder="Email" value="{{ $student->email }}" readonly required>
            </div>
            <div class="input">
                <input type="number" name="phone" placeholder="Phone" value="{{ $student->phone }}" >
            </div>
            <div class="input">
                <input type="text" name="address" placeholder="Address" value="{{ $student->address }}">
            </div>
            <div class="input">
                <select name="gender">
                    <option value="">Gender</option>
                    <option value="Male" {{ $student->gender == 'Male' ? 'selected' : '' }}>Male</option>
                    <option value="Female" {{ $student->gender == 'Female' ? 'selected' : '' }}>Female</option>
                    <option value="Other" {{ $student->gender == 'Other' ? 'selected' : '' }}>Other</option>
                </select>
            </div>
            <div class="input">
                <input type="text" name="department" placeholder="Department" value="{{ $student->department }}">
            </div>
            <div class="input">
                <input hidden type="text" name="usertype" placeholder="User Type" value="{{ $student->usertype }}">
            </div>
            <div class="input">
                <input type="checkbox" id="parttime" name="parttime" value="1" {{ $student->parttime ? 'checked' : '' }}>
                <label for="parttime">Part-time</label>
            </div>
            <div class="input">
                <input type="date" name="joining_date" value="{{ $student->joining_date }}">
            </div>
            <div class="btn">
                <button type="submit" class="signup-btn">Update</button>
            </div>
        </form>
    </div>
</body>
</html>
